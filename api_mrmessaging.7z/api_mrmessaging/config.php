<?php
/*
Autor: Max Kaizer
Create: 30.01.2019 15:10
Version: 1.0
Webmaster e-mail: 707808gg@gmail.com
Telegram: @programistphp
*/
class Configuration
{
  public function config($param)
  {
      $set = [

// Enter your details here

"api_key"    =>   "YOUR_API_KEY", // Your API Key

"username"   =>   "YOUR_USERNAME", // Your username

"phone"      =>   79052223010, // Your phone number

"sender"     =>   "John", // Your sender name

"message"    =>   "Hellow world! Me is John" // Your message here

"country"    =>   false,   // If you need to enable country display, change to - true

"status"     =>   false // If you need to enable status display, change to - true

// End

      ];

      return $set[$param];
  }
}
?>
