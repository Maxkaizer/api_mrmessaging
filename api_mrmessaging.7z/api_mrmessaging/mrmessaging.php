<?php
/*
Autor: Max Kaizer
Create: 30.01.2019 15:10
Version: 1.0
Webmaster e-mail: 707808gg@gmail.com
Telegram: @programistphp
*/
require_once "config.php";
class Mrmessaging extends Configuration
{
  public function __construct()
  {
    // start replace spaces
    $msg = $message;
    $str = array(' ');
    $re = array('+');
    $message = str_replace($str, $re, $msg);
    // end replace spaces
    $url = 'http://api.sms.intel-tele.com/message/send/?username='.$this->set('username').'&';
    $url .= 'api_key='.$this->set('api_key').'&from='.$this->set('sender').'&to='.$this->set('phone').'&';
    $url .= 'message='.$this->set('message');
    $data = file_get_contents($url);
    $get = json_decode($data, true);
    $status = $get['reply'][0]['status'];
    $country = $get['reply'][0]['country'];
    if($status == "OK") {
      return 'Success!';
      if($this->set('country') == true) {
        return ' '.$country; // Show country
      }
      if($this->set('status') == true) {
        return ''. $status; // Show status
      }
      // If you need get array uncomments this:
      /*
      $data = 'Success,'.$status.','.$country;
      $data = explode(',', $data);
      return $data[0]; // Success
      // return $data[1]; // Status
      // return $data[2]; // Country
      */
      // End
    }
    else {
      return 'Error!'; // Error status response
    }
  }
}
// Call method
echo $call = new Mrmessaging(); // Show result
?>
